package com.example.wildcommonsapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class MapActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_map);

        // Oculta la barra de navegación
        hideSystemUI();

        // Referencias a los botones
        Button[] buttons = {
                findViewById(R.id.general_room), // ID 1
                findViewById(R.id.PC1), // ID 2
                findViewById(R.id.PC2), // ID 3
                findViewById(R.id.PC3), // ID 4
                findViewById(R.id.PC4), // ID 5
                findViewById(R.id.PC5), // ID 6
                findViewById(R.id.PC6), // ID 7
                findViewById(R.id.PC7), // ID 8
                findViewById(R.id.PC8), // ID 9
                findViewById(R.id.PC9), // ID 10
                findViewById(R.id.PC10), // ID 11
                findViewById(R.id.PC11), // ID 12
                findViewById(R.id.PC12), // ID 13
                findViewById(R.id.PC13), // ID 14
                findViewById(R.id.PC14), // ID 15
                findViewById(R.id.PC15), // ID 16
                findViewById(R.id.PC16), // ID 17
                findViewById(R.id.PC17), // ID 18
                findViewById(R.id.PC18), // ID 19
                findViewById(R.id.PC19), // ID 20
                findViewById(R.id.PC20), // ID 21
                findViewById(R.id.PC21), // ID 22
                findViewById(R.id.PC22), // ID 23
                findViewById(R.id.PC23), // ID 24
                findViewById(R.id.PC24), // ID 25
                findViewById(R.id.PC25), // ID 26
                findViewById(R.id.PC26), // ID 27
                findViewById(R.id.PC27), // ID 28
                findViewById(R.id.america), // ID 29
                findViewById(R.id.africa), // ID 30
                findViewById(R.id.europe), // ID 31
                findViewById(R.id.asia), // ID 32
                findViewById(R.id.oceania) // ID 33
        };

        // Asignar click listener a cada botón
        for (int i = 0; i < buttons.length; i++) {
            final int assignedId = i + 1; // Asigna el ID correspondiente (del 1 al 33)
            Button button = buttons[i];
            button.setTag(false); // Inicializa el estado como no seleccionado
            button.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    boolean isSelected = (boolean) v.getTag();
                    if (isSelected) {
                        v.setBackgroundResource(R.drawable.button_pc);
                        v.setTag(false);
                    } else {
                        v.setBackgroundResource(R.drawable.button_general_room);
                        v.setTag(true);

                        Intent intent = new Intent(MapActivity.this, InputIdActivity.class);
                        intent.putExtra("buttonId", assignedId); // Envía el ID específico a InputIdActivity
                        intent.putExtra("buttonText", ((Button) v).getText().toString()); // Envía el texto del botón
                        startActivityForResult(intent, 1);
                    }
                }
            });
        }
    }

    private void hideSystemUI() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION // Ocultar la barra de navegación
                        | View.SYSTEM_UI_FLAG_FULLSCREEN // Ocultar la barra de estado
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            hideSystemUI(); // Reocultar la UI del sistema cuando la ventana gana el foco
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1 && resultCode == RESULT_OK) {
            int buttonId = data.getIntExtra("buttonId", -1);
            Button button = findViewById(buttonId);
            if (button != null) {
                // Cambiar el color de fondo de vuelta al original
                button.setBackgroundResource(R.drawable.button_pc);
            }
        }
    }
}
